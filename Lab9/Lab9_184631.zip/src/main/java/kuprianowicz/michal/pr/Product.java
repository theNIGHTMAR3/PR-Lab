package kuprianowicz.michal.pr;

public enum Product {
    BREAD,
    HAM,
    FISH
}
